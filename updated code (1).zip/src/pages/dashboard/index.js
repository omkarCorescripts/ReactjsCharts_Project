import { useEffect, useState } from 'react';

// material-ui
import {
    Avatar,
    AvatarGroup,
    Box,
    Button,
    Grid,
    List,
    ListItemAvatar,
    ListItemButton,
    ListItemSecondaryAction,
    ListItemText,
    MenuItem,
    Stack,
    TextField,
    Typography
} from '@mui/material';

// project import
import OrdersTable from './OrdersTable';
import TankerUtilizationChart from './TankerUtilizationChart';
import MonthlyBarChart from './MonthlyBarChart';
import ReportAreaChart from './ReportAreaChart';
import SalesColumnChart from './SalesColumnChart';
import MainCard from 'components/MainCard';
import AnalyticEcommerce from 'components/cards/statistics/AnalyticEcommerce';

import AccessAlarmIcon from '@mui/icons-material/AccessAlarm';
import DeleteIcon from '@mui/icons-material/Delete';
import WbSunnyIcon from '@mui/icons-material/WbSunny';
import WbTwilightIcon from '@mui/icons-material/WbTwilight';

// assets
import { GiftOutlined, MessageOutlined, SettingOutlined } from '@ant-design/icons';
import avatar1 from 'assets/images/users/avatar-1.png';
import avatar2 from 'assets/images/users/avatar-2.png';
import avatar3 from 'assets/images/users/avatar-3.png';
import avatar4 from 'assets/images/users/avatar-4.png';
import UtilizationPercentageChart from './UtilizationPercentageChart';
import BulkCoolorUtilizationQty from './BulkCoolorUtilizationQty';
import BulkCoolorUtilizationPerc from './BulkCoolorUtilizationPerc';
import MilkCollectionBCwise from './MilkCollectionBCwise';
import MilkCollectionRouteWise from './MilkCollectionRouteWise';


// avatar style
const avatarSX = {
    width: 36,
    height: 36,
    fontSize: '1rem'
};

// action style
const actionSX = {
    mt: 0.75,
    ml: 1,
    top: 'auto',
    right: 'auto',
    alignSelf: 'flex-start',
    transform: 'none'
};

// sales report status
// const status = [
//     {
//         value: 'today',
//         label: 'Today',
//         date: new Date()
//     },
//     {
//         value: 'Last Week',
//         label: 'Last Week',
//     },
//     {
//         value: 'last Month',
//         label: 'Last Month'
//     }
// ];

function Last7Days () {
    return '0123456'.split('').map(function(n) {
        var d = new Date();
        d.setDate(d.getDate() - n);

        return (function(day, month, year) {
            return [day<10 ? '0'+day : day, month<10 ? '0'+month : month, year].join('/');
        })(d.getDate(), d.getMonth(), d.getFullYear());
    }).join(',');
 }
  
// dashboardData
const dummyData = {
    "status": "S",
    "message": null,
    "data": [
      {
        "DispatchDate": "27-Jan-2023",
        "DispatchCount": 8,
        "TotalQty": 6601,
        "MorningQty": 3890,
        "EveningQty": 2711,
        "AvgFAT": 3,
        "AvgSNF": 7.67,
        "lessM1000": 3,
        "gtM1000": 1,
        "gtM2000": 0,
        "gtM3000": 0,
        "lessE1000": 4,
        "gtE1000": 1,
        "gtE2000": 0,
        "gtE3000": 0
      },
      {
        "DispatchDate": "28-Jan-2023",
        "DispatchCount": 11,
        "TotalQty": 40900,
        "MorningQty": 33367,
        "EveningQty": 2005,
        "AvgFAT": 3.5,
        "AvgSNF": 8.12,
        "lessM1000": 10,
        "gtM1000": 10,
        "gtM2000": 3,
        "gtM3000": 1,
        "lessE1000": 17,
        "gtE1000": 1,
        "gtE2000": 1,
        "gtE3000": 0
      }
    ]
  }

  const handleStatus = (date) =>{
console.log('Date :--',date)
  }

// ==============================|| DASHBOARD - DEFAULT ||============================== //

const DashboardDefault = () => {
    var result = dummyData.data.find(function(e) {
        return e.DispatchDate == '27-Jan-2023';
      });
    const [value, setValue] = useState('today');
    const [slot, setSlot] = useState('week');
    const [dashboardData, setDashboardData] = useState(result);
    const [qty, setQty] = useState('');
    const [disCount, setDisCount] = useState('');
    const [mrngQty, setMrngQty] = useState('');
    const [evenQty, setEvenQty] = useState();
    const [avgFat, setAvegFat] = useState();
    const [avgSnf, setAvgSnf] = useState();
    const [lesM1000, setLesM1000] = useState();
    const [gtlM1000, setGtlM1000] = useState();
    const [gtlM2000, setGtlM2000] = useState();
    const [gtlM3000, setGtlM3000] = useState();
    const [lesE1000, setLesE1000] = useState();
    const [gtlE1000, setGtlE1000] = useState();
    const [gtlE2000, setGtlE2000] = useState();
    const [gtlE3000, setGtlE3000] = useState();    
    const [lastSevanDays, setLastSevanDays] = useState([]);

    // useEffect(() => {
    //     const url = "http://20.58.112.55:8084/api/getCountryList";
    //     fetch(url)
    //       .then((response) => response.json())
    //       .then((json) => setDashboardData(json.data) )
    //       .catch((error) => console.log(error));
    //   }, []);
    const status = [
        {
            value: 'today',
            label: 'Today',
            date: new Date()
        },
        {
            value: 'Last Week',
            label: 'Last Week',
            date : lastSevanDays
        },
        {
            value: 'last Month',
            label: 'Last Month'
        }
    ];

    useEffect(()=>{
        setLastSevanDays(Last7Days())
     },[])

console.log('Sevan Days',lastSevanDays);

    useEffect(() => {
        setQty(dashboardData?.TotalQty);
        setDisCount(dashboardData?.DispatchCount);
        setMrngQty(dashboardData?.MorningQty);
        setEvenQty(dashboardData?.EveningQty);
        setAvegFat(dashboardData?.AvgFAT);
        setAvgSnf(dashboardData?.AvgSNF);
        setLesM1000(dashboardData?.lessM1000);
        setGtlM1000(dashboardData?.gtM1000);
        setGtlM2000(dashboardData?.gtM2000);
        setGtlM3000(dashboardData?.gtM3000);
        setLesE1000(dashboardData?.lessE1000);
        setGtlE1000(dashboardData?.gtE1000);
        setGtlE2000(dashboardData?.gtE2000);
        setGtlE3000(dashboardData?.gtE3000);
        console.log(dashboardData);
    }, []);

    return (
        <Grid container rowSpacing={4.5} columnSpacing={2.75}>
            {/* row 1 */}
            <Grid item xs={12} sx={{ mb: -2.25 }}>
                <Typography variant="h5">Dashboard</Typography>
            </Grid>
            <Grid item xs={12} sm={6} md={4} lg={3} >
            <div  style={{ boxShadow: '9px 9px 0px rgba(208, 208, 225, 0.3)', borderRadius: '9px' }}>
                <AnalyticEcommerce title="Liter" count={qty} isLoss color="info" extra="35,000" />
                </div>
            </Grid>
            <Grid item xs={12} sm={6} md={4} lg={3}>
                <div  style={{ boxShadow: '9px 9px 0px rgba(208, 208, 225, 0.3)' , borderRadius: '9px'}}>
                <AnalyticEcommerce title="FAT" count={avgFat} isLoss color="info" extra="8,900" />
                </div>
            </Grid>
            <Grid item xs={12} sm={6} md={4} lg={3}>
                <div  style={{ boxShadow: '9px 9px 0px rgba(208, 208, 225, 0.3)', borderRadius: '9px' }}>
                <AnalyticEcommerce title="SNF" count={avgSnf} isLoss color="info" extra="1,943" />
                </div>
            </Grid>
            <Grid item xs={12} sm={6} md={4} lg={3}>
            <div  style={{ boxShadow: '9px 9px 0px rgba(208, 208, 225, 0.3)', borderRadius: '9px' }}>
                <AnalyticEcommerce title="TruckSheet Count" count={disCount} isLoss color="info" extra="$20,395" />
                </div>
            </Grid>

            <Grid item md={8} sx={{ display: { sm: 'none', md: 'block', lg: 'none' } }} />
            <Grid item xs={12} sm={6} md={4} lg={3}>
                {/* <AnalyticEcommerce title="Morning" count={mrngQty} percentage={59.3} extra="35,000" /> */}
            </Grid>
            <Grid item xs={12} sm={6} md={4} lg={3}>
            <div  style={{ boxShadow: '9px 9px 0px rgba(208, 208, 225, 0.3)', borderRadius: '9px' }}>
                <AnalyticEcommerce title="Morning" count={mrngQty} percentage={70.5} mrngicon={<WbSunnyIcon style={{color:'blue'}}/>} isLoss color="warning" extra="8,900" />
                </div>
            </Grid>        
            <Grid item xs={12} sm={6} md={4} lg={3}>
            <div  style={{ boxShadow: '9px 9px 0px rgba(208, 208, 225, 0.3)', borderRadius: '9px' }}>
                <AnalyticEcommerce title="Evening" count={evenQty} percentage={70.5} mrngicon={<WbTwilightIcon style={{color:'brown'}}/>} isLoss color="warning" extra="8,900" />
                </div>
            </Grid> 
            <Grid item xs={12} sm={6} md={4} lg={3}>
                {/* <AnalyticEcommerce title="Evening" count={evenQty} percentage={70.5} isLoss color="warning" extra="8,900" /> */}
            </Grid>      
            <Grid item md={8} sx={{ display: { sm: 'none', md: 'block', lg: 'none' } }} />
            <Grid item xs={12} sm={2} md={2.5} lg={2}>
                {/* <AnalyticEcommerce title="Morning " percentage="Morning" extra="35,000" /> */}
                <div style={{marginTop:'28px',marginLeft:'20px'}}>
                <Button variant="contained">Morning <WbSunnyIcon style={{color:'blue' , margin:'2',marginLeft:'5'}}/></Button> 
                </div>
            </Grid>
            <Grid item xs={12} sm={2.5} md={2.5} lg={2.5}>
            <div  style={{ boxShadow: '9px 9px 0px rgba(208, 208, 225, 0.3)', borderRadius: '9px' }}>
                <AnalyticEcommerce title="<1000 Ltr" percentage={lesM1000} extra="35,000" />
            </div>
            </Grid>
            <Grid item xs={12} sm={2.5} md={2.5} lg={2.5}>
            <div  style={{ boxShadow: '9px 9px 0px rgba(208, 208, 225, 0.3)', borderRadius: '9px' }}>
                <AnalyticEcommerce title=">1000 Ltr" percentage={gtlM1000} extra="8,900" />
                </div>
            </Grid>
            <Grid item xs={12} sm={2.5} md={2.5} lg={2.5}>
            <div  style={{ boxShadow: '9px 9px 0px rgba(208, 208, 225, 0.3)', borderRadius: '9px' }}>
                <AnalyticEcommerce title=">2000 Ltr" percentage={gtlM2000} extra="8,900" />
                </div>
            </Grid>
            <Grid item xs={12} sm={2.5} md={2.5} lg={2.5}>
            <div  style={{ boxShadow: '9px 9px 0px rgba(208, 208, 225, 0.3)', borderRadius: '9px' }}>
                <AnalyticEcommerce title=">3000 Ltr" percentage={gtlM3000} extra="8,900" />
                </div>
            </Grid>
            <Grid item md={8} sx={{ display: { sm: 'none', md: 'block', lg: 'none' } }} />
            <Grid item xs={12} sm={2} md={2.5} lg={2}>
                {/* <AnalyticEcommerce title="Morning " percentage="Morning" extra="35,000" /> */}
                <div style={{marginTop:'28px',marginLeft:'20px'}}>
                <Button color={'warning'} variant="contained">Evening  <WbTwilightIcon style={{color:'brown',margin:'2',marginLeft:'5'}}/></Button> 
                </div>
            </Grid>
            <Grid item xs={12} sm={2.5} md={2.5} lg={2.5} >
            <div  style={{ boxShadow: '9px 9px 0px rgba(208, 208, 225, 0.3)', borderRadius: '9px' }}>
                <AnalyticEcommerce title="<1000 Ltr" percentage={lesE1000} color={'warning'} extra="35,000" />
                </div>
            </Grid>
            <Grid item xs={12} sm={2.5} md={2.5} lg={2.5}>
            <div  style={{ boxShadow: '9px 9px 0px rgba(208, 208, 225, 0.3)', borderRadius: '9px' }}>
                <AnalyticEcommerce title=">1000 Ltr" percentage={gtlE1000} color={'warning'} extra="8,900" />
                </div>
            </Grid>
            <Grid item xs={12} sm={2.5} md={2.5} lg={2.5}>
            <div  style={{ boxShadow: '9px 9px 0px rgba(208, 208, 225, 0.3)', borderRadius: '9px' }}>
                <AnalyticEcommerce title=">2000 Ltr" percentage={gtlE2000} color={'warning'} extra="8,900" />
                </div>
            </Grid>
            <Grid item xs={12} sm={2.5} md={2.5} lg={2.5}>
            <div  style={{ boxShadow: '9px 9px 0px rgba(208, 208, 225, 0.3)', borderRadius: '9px' }}>
                <AnalyticEcommerce title=">3000 Ltr"  percentage={gtlE3000} color={'warning'}  extra="8,900" />
                </div>
            </Grid>

            {/* row 2 */}
            <Grid item xs={12} md={6} lg={6}>
                <Grid container alignItems="center" justifyContent="space-between">
                    <Grid item>
                        <Typography variant="h5">Tanker Utilization -Qty</Typography>
                    </Grid>
                    <Grid item>
                        <TextField
                            id="standard-select-currency"
                            size="small"
                            select
                            value={value}
                            onChange={(e) => setValue(e.target.value)}
                            sx={{ '& .MuiInputBase-input': { py: 0.5, fontSize: '0.875rem' } }}
                        >
                            {status.map((option) => (
                                <MenuItem onClick={()=>handleStatus(option.date)} key={option.value} value={option.value}>
                                    {option.label}
                                </MenuItem>
                            ))}
                        </TextField>
                    </Grid>
                </Grid>
                <MainCard content={false} sx={{ mt: 1.5 }}>
                    <Box sx={{ pt: 1, pr: 2 }}>
                        <TankerUtilizationChart slot={slot} />
                    </Box>
                </MainCard>
            </Grid>
            <Grid item xs={12} md={6} lg={6}>
                <Grid container alignItems="center" justifyContent="space-between">
                    <Grid item>
                        <Typography variant="h5">Tanker Utilization - %</Typography>
                    </Grid>
                    <Grid item>
                        <TextField
                            id="standard-select-currency"
                            size="small"
                            select
                            value={value}
                            onChange={(e) => setValue(e.target.value)}
                            sx={{ '& .MuiInputBase-input': { py: 0.5, fontSize: '0.875rem' } }}
                        >
                            {status.map((option) => (
                                <MenuItem onClick={()=>handleStatus(option.date)} key={option.value} value={option.value}>
                                    {option.label}
                                </MenuItem>
                            ))}
                        </TextField>
                    </Grid>
                </Grid>
                <MainCard sx={{ mt: 2 }} content={false}>
                    {/* <Box sx={{ p: 3, pb: 0 }}>
                        <Stack spacing={2}>
                            <Typography variant="h6" color="textSecondary">
                                This Week Statistics
                            </Typography>
                            <Typography variant="h3">$7,650</Typography>
                        </Stack>
                    </Box> */}
                    {/* <MonthlyBarChart /> */}
                    <UtilizationPercentageChart/>
                </MainCard>
            </Grid>

            {/* row 3 */}
            {/* <Grid item xs={12} md={7} lg={8}>
                <Grid container alignItems="center" justifyContent="space-between">
                    <Grid item>
                        <Typography variant="h5">Recent Orders</Typography>
                    </Grid>
                    <Grid item />
                </Grid>
                <MainCard sx={{ mt: 2 }} content={false}>
                    <OrdersTable />
                </MainCard>
            </Grid>
            <Grid item xs={12} md={5} lg={4}>
                <Grid container alignItems="center" justifyContent="space-between">
                    <Grid item>
                        <Typography variant="h5">Analytics Report</Typography>
                    </Grid>
                    <Grid item />
                </Grid>
                <MainCard sx={{ mt: 2 }} content={false}>
                    <List sx={{ p: 0, '& .MuiListItemButton-root': { py: 2 } }}>
                        <ListItemButton divider>
                            <ListItemText primary="Company Finance Growth" />
                            <Typography variant="h5">+45.14%</Typography>
                        </ListItemButton>
                        <ListItemButton divider>
                            <ListItemText primary="Company Expenses Ratio" />
                            <Typography variant="h5">0.58%</Typography>
                        </ListItemButton>
                        <ListItemButton>
                            <ListItemText primary="Business Risk Cases" />
                            <Typography variant="h5">Low</Typography>
                        </ListItemButton>
                    </List>
                    <ReportAreaChart />
                </MainCard>
            </Grid> */}

            {/* row 4 */}
            <Grid item xs={12} md={6} lg={6}>
                <Grid container alignItems="center" justifyContent="space-between">
                    <Grid item>
                        <Typography style={{ color: 'Brown' }} variant="h5">Bulk Cooler Utilization - Qty</Typography>
                    </Grid>
                    <Grid item>
                        <TextField
                            id="standard-select-currency"
                            size="small"
                            select
                            value={value}
                            onChange={(e) => setValue(e.target.value)}
                            sx={{ '& .MuiInputBase-input': { py: 0.5, fontSize: '0.875rem' } }}
                        >
                            {status.map((option) => (
                                <MenuItem onClick={()=>handleStatus(option.date)} key={option.value} value={option.value}>
                                    {option.label}
                                </MenuItem>
                            ))}
                        </TextField>
                    </Grid>
                </Grid>
                <MainCard content={false} sx={{ mt: 1.5 }}>
                    <Box sx={{ pt: 1, pr: 2 }}>
                        <BulkCoolorUtilizationQty slot={slot} />
                    </Box>
                </MainCard>
            </Grid>
            <Grid item xs={12} md={6} lg={6}>
                <Grid container alignItems="center" justifyContent="space-between">
                    <Grid item>
                        <Typography style={{ color: 'Brown' }} variant="h5">Bulk Cooler Utilization - %</Typography>
                    </Grid>
                    <Grid item>
                        <TextField
                            id="standard-select-currency"
                            size="small"
                            select
                            value={value}
                            onChange={(e) => setValue(e.target.value)}
                            sx={{ '& .MuiInputBase-input': { py: 0.5, fontSize: '0.875rem' } }}
                        >
                            {status.map((option) => (
                                <MenuItem onClick={()=>handleStatus(option.date)} key={option.value} value={option.value}>
                                    {option.label}
                                </MenuItem>
                            ))}
                        </TextField>
                    </Grid>
                </Grid>
                <MainCard content={false} sx={{ mt: 1.5 }}>
                    <Box sx={{ pt: 1, pr: 2 }}>
                        <BulkCoolorUtilizationPerc slot={slot} />
                    </Box>
                </MainCard>
            </Grid>
            <Grid item xs={12} md={6} lg={6}>
                <Grid container alignItems="center" justifyContent="space-between">
                    <Grid item>
                        <Typography style={{ color: 'red' }} variant="h5">Milk Collection - BC Wise</Typography>
                    </Grid>
                    <Grid item>
                        <TextField
                            id="standard-select-currency"
                            size="small"
                            select
                            value={value}
                            onChange={(e) => setValue(e.target.value)}
                            sx={{ '& .MuiInputBase-input': { py: 0.5, fontSize: '0.875rem' } }}
                        >
                            {status.map((option) => (
                                <MenuItem onClick={()=>handleStatus(option.date)} key={option.value} value={option.value}>
                                    {option.label}
                                </MenuItem>
                            ))}
                        </TextField>
                    </Grid>
                </Grid>
                <MainCard sx={{ mt: 1.75 }}>
                    {/* <Stack spacing={1.5} sx={{ mb: -12 }}>
                        <Typography variant="h6" color="secondary">
                            Net Profit
                        </Typography>
                        <Typography variant="h4">$1560</Typography>
                    </Stack> */}
                    <MilkCollectionBCwise />
                </MainCard>
            </Grid>
            <Grid item xs={12} md={6} lg={6}>
                <Grid container alignItems="center" justifyContent="space-between">
                    <Grid item>
                        <Typography style={{ color: 'red' }} variant="h5" >Milk Collection - Route Wise</Typography>
                    </Grid>
                    <Grid item>
                        <TextField
                            id="standard-select-currency"
                            size="small"
                            select
                            value={value}
                            onChange={(e) => setValue(e.target.value)}
                            sx={{ '& .MuiInputBase-input': { py: 0.5, fontSize: '0.875rem' } }}
                        >
                            {status.map((option) => (
                                <MenuItem onClick={()=>handleStatus(option.date)} key={option.value} value={option.value}>
                                    {option.label}
                                </MenuItem>
                            ))}
                        </TextField>
                    </Grid>
                </Grid>
                <MainCard content={false} sx={{ mt: 1.5 }}>
                    <Box sx={{ pt: 1, pr: 2 }}>
                        <MilkCollectionRouteWise slot={slot} />
                    </Box>
                </MainCard>
            </Grid>
          
        </Grid>
    );
};

export default DashboardDefault;
