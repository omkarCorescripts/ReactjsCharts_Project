import PropTypes from 'prop-types';
import { useState, useEffect } from 'react';

// material-ui
import { useTheme } from '@mui/material/styles';

// third-party
import ReactApexChart from 'react-apexcharts';

// chart options
const areaChartOptions = {
    chart: {
        height: 450,
        type: 'area',
        toolbar: {
            show: false
        }
    },
    dataLabels: {
        enabled: false
    },
    stroke: {
        curve: 'smooth',
        width: 2
    },
    grid: {
        strokeDashArray: 0
    },
};

const ChartData = {
    "status": "S",
    "message": null,
    "RouteList": [
      
        "all - 01",
        "BARSHI FOUR - 348",
        "BARSHI THREE - 342",
        "HAVELI - 300",
        "INDAPUR TWO - 308",
        "KARJAT FOUR - 335",
        "KARMALA FOUR - 344",
        "KARMALA ONE - 318",
        "Nashik - 10",
        "TEST 2 - 22121",
        "TEST-T2 - 1221"
      
    ],
    "UtilList": [
      
        0,
        62805,
        87559,
        9970,
        100624,
        49105,
        52996,
        36632,
        3516,
        12548,
        25836
      
    ]
  }

// ==============================|| INCOME AREA CHART ||============================== //

const MilkCollectionRouteWise = ({ slot }) => {
    const theme = useTheme();

    const { primary, secondary } = theme.palette.text;
    const line = theme.palette.divider;

    const [options, setOptions] = useState(areaChartOptions);
    const [bmcList, setBmcList] = useState(ChartData.RouteList);
    const [utillList, setUtillList] = useState(ChartData.UtilList);
    // const [ChartData,  setChartData] = useState([]);

    // useEffect(() => {
    //     const url = "http://20.58.112.55:8084/api/getCountryList";
    //     fetch(url)
    //       .then((response) => response.json())
    //       .then((json) => setChartData(json.data) )
    //       .catch((error) => console.log(error));
    //   }, []);

    useEffect(() => {
        setOptions((prevState) => ({
            ...prevState,
            colors: [theme.palette.primary.main, theme.palette.primary[700]],
            chart:{ toolbar: {
                show: true
              },},
            xaxis: {
                categories:bmcList,
                labels: {
                    style: {
                        colors: [
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary
                        ]
                    }
                },
                axisBorder: {
                    show: true,
                    color: line
                },
                labels: {
                    show: true,
                    rotateAlways: true,
                    minHeight: undefined
                  },
            },
            yaxis: {
                labels: {
                    style: {
                        colors: [secondary]
                    }
                }
            },
            grid: {
                borderColor: line
            },
            tooltip: {
                theme: 'light'
            }
        }));
    }, [primary, secondary, line, theme, slot]);

    const [series, setSeries] = useState([
        {
            name: '',
            data: []
        },
        {
            name: 'Actual',
            data: utillList
        }
    ]);

    useEffect(() => {
        setSeries([
            {
                name: '',
                data: slot === 'month' ? [] : []
            },
            {
                name: 'Actual',
                data: utillList
            }
        ]);
    }, [slot]);

    return <div>  
    <ReactApexChart options={options} series={series} type="area" height={450} />
</div>
};

MilkCollectionRouteWise.propTypes = {
    slot: PropTypes.string
};

export default MilkCollectionRouteWise;
