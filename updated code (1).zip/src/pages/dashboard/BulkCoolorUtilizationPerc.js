import PropTypes from 'prop-types';
import { useState, useEffect } from 'react';

// material-ui
import { useTheme } from '@mui/material/styles';

// third-party
import ReactApexChart from 'react-apexcharts';

// chart options
const areaChartOptions = {
    chart: {
        height: 450,
        type: 'area',
        toolbar: {
            show: false
        }
    },
    dataLabels: {
        enabled: false
    },
    stroke: {
        curve: 'smooth',
        width: 2
    },
    grid: {
        strokeDashArray: 0
    }
};

const ChartData = {
    "status": "S",
    "message": null,
    "BMCList": [  
        "ANJANGAON",
        "BALEWADI",
        "BARADGAON",
        "BHAGATWADI",
        "BHOYARE",
        "BORGAON",
        "CHIKHAL",
        "DEGAON",
        "DEVADI",
        "DEVLALI",
        "DURGAON",
        "EKURKE",
        "GALANDWADI",
        "GALANDWADI",
        "GANESHWADI",
        "HIVARWADI",
        "JAGDALEWASTI",
        "KAUTHALI",
        "KAUTHALI ",
        "KAUTHALI",
        "KEDGAON",
        "KETUR1",
        "KETUR2",
        "KHANDOBACHIWADI2",
        "KHANDOBACHIWADI1",
        "KHANOTA ",
        "KORTI",
        "KUMBHARGAON",
        "MADAN WADI",
        "MALTHAN (D)",
        "MALWADI NO 2",
        "MANEGAON",
        "MANJARGAON",
        "MHASOBACHI WADI",
        "NANDGAON",
        "PADSTHAL (CHINDADEVI)",
        "Pothare",
        "RAJURI K",
        "ROPALE",
        "RUI-2",
        "SADE",
        "SHELGAON(K)",
        "SUPEKARWADI",
        "SURVEWASTI (MODNIMB)",
        "TAKALI R",
        "VEET",
        "WALUNJ",
        "WAYASEWADI",
        "ZARE"
    ],
    "UtilPerList": [
      
        20.87,
        44.24,
        49.47,
        34.82,
        70.87,
        32,
        38.86,
        81.26,
        101.92,
        14,
        74.25,
        72.26,
        73.25,
        62.42,
        103.22,
        21.28,
        50.18,
        30.36,
        135.2,
        70.81,
        0,
        67.59,
        52.45,
        57.24,
        15.51,
        13.76,
        88.56,
        64.71,
        60.91,
        22.08,
        46.39,
        63.77,
        88.63,
        34.11,
        20.89,
        13.89,
        0,
        11.9,
        0,
        11.58,
        87.01,
        46.88,
        110.34,
        49.59,
        15.45,
        0,
        40.06,
        106.99,
        0
      
    ]
  }

// ==============================|| INCOME AREA CHART ||============================== //

const BulkCoolorUtilizationPerc = ({ slot }) => {
    const theme = useTheme();

    const { primary, secondary } = theme.palette.text;
    const line = theme.palette.divider;

    const [options, setOptions] = useState(areaChartOptions);
    const [bmcList, setBmcList] = useState(ChartData.BMCList);
    const [utillList, setUtillList] = useState(ChartData.UtilPerList);
    // const [ChartData,  setChartData] = useState([]);

     // useEffect(() => {
    //     const url = "http://20.58.112.55:8084/api/getCountryList";
    //     fetch(url)
    //       .then((response) => response.json())
    //       .then((json) => setChartData(json.data) )
    //       .catch((error) => console.log(error));
    //   }, []);

    useEffect(() => {
        setOptions((prevState) => ({
            ...prevState,
            colors: [theme.palette.primary.main, theme.palette.primary[700]],
            chart:{
                toolbar: {
                show: true
              }, 
              zoom: {
                enabled: true,
                type: 'x',
              },
              },
              legend: {
                height: 35,
                offsetY: 15,
                position: 'top',
                horizontalAlign: 'center',  },
            xaxis: {
                categories:  bmcList,
                crosshairs: {
                            show: false
                }, 
                labels: {
                    style: {
                        fontSize: '8.8px',
                        textAlign: 'center', 
                        colors: [
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary
                        ]
                    }                    
                },
                labels: {
                    show: true,
                    rotateAlways: true,
                    minHeight: undefined
                  },
            },
            yaxis: {
                labels: {
                    style: {
                        colors: [secondary]
                    }
                }
            },
            grid: {
                borderColor: line
            },
            tooltip: {
                theme: 'light'
            },
             fill: {
                type: 'gradient'
              },
              responsive: [
                {
                  breakpoint: 1000,
                  options: {
                    chart: {
                      toolbar: {
                        show: true,
                      },
                    },
                  },
                },
              ],
        }))
    }, [primary, secondary, line, theme, slot]);

    const [series, setSeries] = useState([
        {
            name: '',
            data: []
        },
        {
            name: 'Actual',
            data: utillList
        }
    ]);

    useEffect(() => {
        setSeries([
            {
                name: '',
                data: []
            },
            {
                name: 'Actual',
                data: utillList
            }
        ]);
    }, [slot]);

    return    <div>   
        <ReactApexChart options={options} series={series} type="area" height={450} />
        </div>
};

BulkCoolorUtilizationPerc.propTypes = {
    slot: PropTypes.string
};

export default BulkCoolorUtilizationPerc;
