import PropTypes from 'prop-types';
import { useState, useEffect } from 'react';

// material-ui
import { useTheme } from '@mui/material/styles';

// third-party
import ReactApexChart from 'react-apexcharts';

// chart options
const areaChartOptions = {
    chart: {
        height: 450,
        type: 'area',
        toolbar: {
            show: false
        }
    },
    dataLabels: {
        enabled: false
    },
    stroke: {
        curve: 'smooth',
        width: 2
    },
    grid: {
        strokeDashArray: 0
    }
};

const ChartData = {
    "status": "S",
    "message": null,
    "TankerList": [
     
        "MH12-DG9968",
        "MH12-DT1212",
        "MH12-HD5402",
        "MH12-KP4700",
        "MH16-AE7917",
        "MH16-Q7201",
        "MH42-AQ3555",
        "MH42-AQ7869",
        "MH42-AQ8017",
        "MH42-AQ8080",
        "MH42-AQ9898",
        "MH42-B8017",
        "MH42-B8134",
        "MH42-T1989",
        "MH42-T4876",
        "MH42-T937",
        "MH42-T954"
      
    ],
    "CapacityList": [
      
        9400,
        9350,
        9100,
        9700,
        9600,
        9300,
        10300,
        11000,
        12800,
        9700,
        13000,
        16400,
        9300,
        10000,
        9400,
        9500,
        10500
      
    ],
    "UtilList": [
      
        1600,
        6678,
        429,
        6699,
        1839,
        2200,
        8275,
        10196,
        2500,
        0,
        6199.5,
        1305.33,
        1129.5,
        1362,
        7437,
        9141,
        4389.5
      
    ]
  }

// ==============================|| INCOME AREA CHART ||============================== //

const TankerUtilizationChart = ({ slot }) => {
    const theme = useTheme();

    const { primary, secondary } = theme.palette.text;
    const line = theme.palette.divider;

    const [options, setOptions] = useState(areaChartOptions);
    const [bmcList, setBmcList] = useState(ChartData.TankerList);
    const [bmcCapaList, setBmcCapaList] = useState(ChartData.CapacityList);
    const [utillList, setUtillList] = useState(ChartData.UtilList);
    // const [ChartData,  setChartData] = useState([]);

    // useEffect(() => {
    //     const url = "http://20.58.112.55:8084/api/getCountryList";
    //     fetch(url)
    //       .then((response) => response.json())
    //       .then((json) => setChartData(json.data) )
    //       .catch((error) => console.log(error));
    //   }, []);

    useEffect(() => {
        setOptions((prevState) => ({
            ...prevState,
            colors: [theme.palette.primary.main, theme.palette.primary[700]],
            chart:{ toolbar: {
                show: true
              },},
            xaxis: {
                categories:bmcList,
                labels: {
                    style: {
                        fontSize: '9px',
                        textAlign: 'center',
                        colors: [
                            secondary,
                        ]
                    }
                },
                 labels: {
                        show: true,
                        rotateAlways: true,
                        minHeight: undefined
                      },
                axisBorder: {
                    show: true,
                    color: line
                },
            },
            yaxis: {
                labels: {
                    style: {
                        colors: [secondary]
                    }
                }
            },
            grid: {
                borderColor: line
            },
            tooltip: {
                theme: 'light'
            },
            fill: {
                type: 'gradient'
              },
            responsive: [
                {
                  breakpoint: 100,
                  options: {
                    chart: {
                      toolbar: {
                        show: true,
                      },
                    },
                    legend: {
                        show: false
                      },
                  },
                },
              ],
        }));
    }, [primary, secondary, line, theme, slot]);

    const [series, setSeries] = useState([
        {
            name: 'Capacity',
            data: bmcCapaList
        },
        {
            name: 'Actual',
            data: utillList
        }
    ]);

    useEffect(() => {
        setSeries([
            {
                name: 'Capacity',
                data: bmcCapaList 
            },
            {
                name: 'Actual',
                data:  utillList 
            }
        ]);
    }, [slot]);

    return <div>   
    <ReactApexChart options={options} series={series} type="area" height={450} />
    </div>
};

TankerUtilizationChart.propTypes = {
    slot: PropTypes.string
};

export default TankerUtilizationChart;
