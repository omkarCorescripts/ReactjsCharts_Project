import PropTypes from 'prop-types';
import { useState, useEffect } from 'react';

// material-ui
import { useTheme } from '@mui/material/styles';

// third-party
import ReactApexChart from 'react-apexcharts';

// chart options
const areaChartOptions = {
    chart: {
        height: 450,
        type: 'area',
        toolbar: {
            show: false
        }
    },
    dataLabels: {
        enabled: false
    },
    stroke: {
        curve: 'smooth',
        width: 2
    },
    grid: {
        strokeDashArray: 0
    },
    annotations: {
        yaxis: [{
          y: 80,
          borderColor: '#FF4560',
          label: {
            borderColor: '#FF4560',
            style: {
              color: '#fff',
              background: '#FF4560'
            },
            text: 'Target'
          }
        }]
      },
};

const ChartData = {
    "status": "S",
    "message": null,
    "TankerList": [
      
        "MH12-DG9968",
        "MH12-DT1212",
        "MH12-HD5402",
        "MH12-KP4700",
        "MH16-AE7917",
        "MH16-Q7201",
        "MH42-AQ3555",
        "MH42-AQ7869",
        "MH42-AQ8017",
        "MH42-AQ8080",
        "MH42-AQ9898",
        "MH42-B8017",
        "MH42-B8134",
        "MH42-T1989",
        "MH42-T4876",
        "MH42-T937",
        "MH42-T954"
      
    ],
    "UtilPerList": [
      
        17.02,
        71.42,
        4.71,
        69.06,
        19.16,
        23.66,
        80.34,
        92.7,
        19.53,
        0,
        47.69,
        7.96,
        12.15,
        13.62,
        79.12,
        96.22,
        41.81
      
    ]
  }

// ==============================|| INCOME AREA CHART ||============================== //

const UtilizationPercentageChart = ({ slot }) => {
    const theme = useTheme();

    const { primary, secondary } = theme.palette.text;
    const line = theme.palette.divider;

    const [options, setOptions] = useState(areaChartOptions);
    const [bmcList, setBmcList] = useState(ChartData.TankerList);
    const [utillList, setUtillList] = useState(ChartData.UtilPerList);
    // const [ChartData,  setChartData] = useState([]);

    // useEffect(() => {
    //     const url = "http://20.58.112.55:8084/api/getCountryList";
    //     fetch(url)
    //       .then((response) => response.json())
    //       .then((json) => setChartData(json.data) )
    //       .catch((error) => console.log(error));
    //   }, []);

    useEffect(() => {
        setOptions((prevState) => ({
            ...prevState,
            colors: [theme.palette.primary.main, theme.palette.primary[700]],
            chart:{ toolbar: {
                show: true
              },},
            xaxis: {
                categories:bmcList,
                labels: {
                    style: {
                        fontSize: '9px',
                        textAlign: 'center',
                        colors: [
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary
                        ]
                    }
                },
                axisBorder: {
                    show: true,
                    color: line
                },
                labels: {
                    show: true,
                    rotateAlways: true,
                    minHeight: undefined
                  },
            },
            yaxis: {
                labels: {
                    style: {
                        colors: [secondary]
                    }
                }
            },
            grid: {
                borderColor: line
            },
            tooltip: {
                theme: 'light'
            },
            fill: {
                type: 'gradient'
              },
              responsive: [
                {
                  breakpoint: 100,
                  options: {
                    chart: {
                      toolbar: {
                        show: true,
                      },
                    },
                    legend: {
                        show: false
                      },
                  },
                },
              ],
        }));
    }, [primary, secondary, line, theme, slot]);

    const [series, setSeries] = useState([
        {
            name: 'Capacity',
            data: []
        },
        {
            name: 'Actual',
            data: utillList
        }
    ]);

    useEffect(() => {
        setSeries([
            {
                name: 'Capacity',
                data:  []
            },
            {
                name: 'Actual',
                data:  utillList 
            }
        ]);
    }, [slot]);

    return <div >   
    <ReactApexChart options={options} series={series} type="area" height={450} />
    </div>
};

UtilizationPercentageChart.propTypes = {
    slot: PropTypes.string
};

export default UtilizationPercentageChart;
