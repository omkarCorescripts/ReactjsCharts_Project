import PropTypes from 'prop-types';
import { useState, useEffect } from 'react';
// material-ui
import { useTheme } from '@mui/material/styles';

// third-party
import ReactApexChart from 'react-apexcharts';

// chart options
const areaChartOptions = {
    chart: {
        height: 450,
        width: "100%",
        id: "chart1",
        type: 'area',
        toolbar: {
            show: false
        },
        zoom: {
            type: "x",
            enabled: true
          }
    },
    dataLabels: {
        enabled: false
    },
    stroke: {
        curve: 'smooth',
        width: 2
    },
    grid: {
        strokeDashArray: 1
    },
};

const ChartData = {
    "status": "S",
    "message": null,
    "BMCList": [
        "ANJANGAON (KHELOBA)",
        "BALEWADI",
        "BARADGAON SUDRIK",
        "BHAGATWADI",
        "BHOYARE(NARKHED0",
        "BORGAON K",
        "CHIKHALTHAN",
        "DEGAON(Wa)",
        "DEVADI",
        "DEVLALI K",
        "DURGAON",
        "EKURKE"
    ],
    "UtilList": [
        1127,
        3185,
        4947,
        1880,
        22679,
        640,
        1399,
        10239,
        49533,
        252,
        25839,
        10116
    ]
  }

  const brushOptions = {
    chart: {
      id: "chart2",
      height: 120,
      width: "100%",
      type: "area",
      brush: {
        target: "chart1",
        enabled: true
      },
      selection: {
        enabled: true
      }
    },
    colors: ["#008FFB", "#008FFB"],
    fill: {
      type: "gradient",
      gradient: {
        opacityFrom: 0.91,
        opacityTo: 0.1
      }
    },
    xaxis: {
     
    },
    legend: {
      show: false
    }
  };
  

// ==============================|| INCOME AREA CHART ||============================== //

const MilkCollectionBCwise = ({ slot }) => {
    const theme = useTheme();

    const { primary, secondary } = theme.palette.text;
    const line = theme.palette.divider;

    const [options, setOptions] = useState(areaChartOptions);
    const [bmcList, setBmcList] = useState(ChartData.BMCList);
    const [utillList, setUtillList] = useState(ChartData.UtilList);
    const [optionLine, setoptionLine] = useState(brushOptions)
    // const [ChartData,  setChartData] = useState([]);

    // useEffect(() => {
    //     const url = "http://20.58.112.55:8084/api/getCountryList";
    //     fetch(url)
    //       .then((response) => response.json())
    //       .then((json) => setChartData(json.data) )
    //       .catch((error) => console.log(error));
    //   }, []);

    useEffect(() => {
        setOptions((prevState) => ({
            ...prevState,
            colors: [theme.palette.primary.main, theme.palette.primary[700]],
            chart:{ 
                id: "chart1",
                type: "area",
                width: "100%",
                toolbar: {
                show: true,
                tools: {
                    reset: false
                  }
              },
              zoom: {
                type: "x",
                enabled: true
              }
            },
              legend: {
                height: 35,
                offsetY: 15,
                position: 'top',
                horizontalAlign: 'center',  },
              stroke: {
                width: 3
              },
              dataLabels: {
                enabled: false
              },
              markers: {
                size: 0
              },
              colors: ["#008FFB", "#008FFB"],
            xaxis: {
                type:'',
                categories:bmcList,
                labels: {
                    style: {
                        colors: [
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary
                        ]
                    },
                    offsetY: 0,
                },            
                axisBorder: {
                    show: false,
                    color: line
                },
            },
            yaxis: [
                {
                    opposite: true,
                    axisBorder: {
                        show: false,
                        color: "#0093D1"
                      },
                    labels: {
                        style: {
                            colors: [secondary]
                        }
                    }
                },
                {
                    // opposite: true,
                    axisBorder: {
                        show: false,
                        color: "#0093D1"
                      },
                    labels: {
                        style: {
                            colors: [secondary]
                        }
                    }
                }
          
            ],
            tooltip: {
                theme: 'light'
            }
        }));

        setoptionLine((prevState) => ({
         ...prevState,
         chart: {
            id: "chart2",
            height: 120,
            width: "100%",
            type: "area",
            brush: {
              target: "chart1",
              enabled: true
            },
            selection: {
              enabled: true
            }
          },
          colors: ["#008FFB", "#008FFB"],
          fill: {
            type: "gradient",
            gradient: {
              opacityFrom: 0.91,
              opacityTo: 0.1
            }
          },
          xaxis: {
            labels: {
                show: false // Hide the X-axis labels
              },         
          },
          yaxis:{
            labels: {
                show: false // Hide the X-axis labels
              }
          },
          legend: {
            show: false
          }
        }))


    }, [primary, secondary, line, theme, slot]);

    const [series, setSeries] = useState([
        {
            name: '',
            data: []
        },
        {
            name: 'Actual',
            data: utillList
        }
    ]);

    useEffect(() => {
        setSeries([
            {
                name: '',
                data:  []
            },
            {
                name: 'Actual',
                data: utillList
            }
        ]);
    }, [slot]);

    return <div>  
    <ReactApexChart options={options} series={series} type="area" height={500} width={'100%'} style={{marginBottom:'10px'}}/>
    <div style={{marginTop:-30,marginBottom:-30}} >   
    <ReactApexChart options={optionLine} series={series} type="area" height={110} />
    </div>
</div>
};

MilkCollectionBCwise.propTypes = {
    slot: PropTypes.string
};

export default MilkCollectionBCwise;
