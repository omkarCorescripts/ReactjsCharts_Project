import PropTypes from 'prop-types';
import { useState, useEffect } from 'react';

// material-ui
import { useTheme } from '@mui/material/styles';

// third-party
import ReactApexChart from 'react-apexcharts';

// chart options
const areaChartOptions = {
    chart: {
        height: 450,
        type: 'area',
        toolbar: {
            show: false
        }
    },
    dataLabels: {
        enabled: false
    },
    stroke: {
        curve: 'smooth',
        width: 2
    },
    grid: {
        strokeDashArray: 0
    }
};

const ChartData = {
    "status": "S",
    "message": null,
    "BMCList": [
        "ANJANGAON (KHELOBA)",
        "BALEWADI",
        "BARADGAON SUDRIK",
        "BHAGATWADI",
        "BHOYARE(NARKHED0",
        "BORGAON K",
        "CHIKHALTHAN",
        "DEGAON(Wa)",
        "DEVADI",
        "DEVLALI K",
        "ANJANGAON (KHELOBA)",
        "BALEWADI",
        "BARADGAON SUDRIK",
        "BHAGATWADI",
        "BHOYARE(NARKHED0",
        "BORGAON K",
        "CHIKHALTHAN",
        "DEGAON(Wa)",
        "DEVADI",
        "DEVLALI K",
    ],
    "BMCCapacityList": [
        1800,
        1800,
        2000,
        1800,
        4000,
        2000,
        1800,
        1800,
        5400,
        1800,
        1800,
        1800,
        2000,
        1800,
        4000,
        2000,
        1800,
        1800,
        5400,
        1800
    ],
    "UtilList": [
        375.67,
        796.25,
        989.4,
        626.67,
        2834.88,
        640,
        699.5,
        1462.71,
        5503.67,
        252,
        375.67,
        796.25,
        989.4,
        626.67,
        2834.88,
        640,
        699.5,
        1462.71,
        5503.67,
        252
    ]
  }

// ==============================|| INCOME AREA CHART ||============================== //

const BulkCoolorUtilizationQty = ({ slot }) => {
    const theme = useTheme();

    const { primary, secondary } = theme.palette.text;
    const line = theme.palette.divider;

    const [options, setOptions] = useState(areaChartOptions);
    const [bmcList, setBmcList] = useState(ChartData.BMCList);
    const [bmcCapaList, setBmcCapaList] = useState(ChartData.BMCCapacityList);
    const [utillList, setUtillList] = useState(ChartData.UtilList);
    // const [ChartData,  setChartData] = useState([]);

    // useEffect(() => {
    //     const url = "http://20.58.112.55:8084/api/getCountryList";
    //     fetch(url)
    //       .then((response) => response.json())
    //       .then((json) => setChartData(json.data) )
    //       .catch((error) => console.log(error));
    //   }, []);

    useEffect(() => {
        setOptions((prevState) => ({
            ...prevState,
            colors: [theme.palette.primary.main, theme.palette.primary[700]],
            chart:{
                 toolbar: {
                show: true
              },
              zoom: {
                enabled: true,
                type: 'x',
              },},
            xaxis: {
                categories:bmcList,
                crosshairs: {
                    show: false
        }, 
                labels: {
                    style: {
                        fontSize: '8.8px',
                        textAlign: 'center',
                        colors: [
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary,
                            secondary
                        ]
                    }
                },
                labels: {
                    show: true,
                    rotateAlways: true,
                    minHeight: undefined
                  },
            },
            yaxis: {
                labels: {
                    style: {
                        colors: [secondary]
                    }
                }
            },
            grid: {
                borderColor: line
            },
            tooltip: {
                theme: 'dark'
            },
             fill: {
                type: 'gradient'
              },
                  responsive: [
                {
                  breakpoint: 1000,
                  options: {
                    chart: {
                      toolbar: {
                        show: true,
                      },
                    },
                  },
                },
              ],
        }));
    }, [primary, secondary, line, theme, slot]);

    const [series, setSeries] = useState([
        {
            name: 'Capacity',
            data: bmcCapaList
        },
        {
            name: 'Actual',
            data: utillList
        }
    ]);

    useEffect(() => {
        setSeries([
            {
                name: 'Capacity',
                data: bmcCapaList 
            },
            {
                name: 'Actual',
                data: utillList 
            }
        ]);
    }, []);

    return <ReactApexChart options={options} series={series} type="area" height={450} />;
};

BulkCoolorUtilizationQty.propTypes = {
    slot: PropTypes.string
};

export default BulkCoolorUtilizationQty;
